<!-- Header banner -->
<img src="https://capsule-render.vercel.app/api?type=waving&color=gradient&customColorList=12,14,18&height=200&section=header&text=Sadiqur%20Rahman&fontSize=46&fontColor=ffffff&fontAlignY=36&desc=MERN%20Stack%20%26%20React%20Native%20Developer&descSize=18&descAlignY=58" width="100%" alt="Header" />

<div align="center">

<a href="https://devsadiq.com/">
  <img src="https://readme-typing-svg.demolab.com?font=Fira+Code&weight=600&size=22&pause=1200&color=2F81F7&center=true&vCenter=true&width=640&lines=Full-Stack+MERN+Developer;I+build+fast%2C+scalable+web+apps;Currently+at+SREDA%2C+Bangladesh;Open+to+freelance+%26+remote+work" alt="Typing SVG" />
</a>

<p>
  <img src="https://komarev.com/ghpvc/?username=sadiqur199&label=Profile%20Views&color=2F81F7&style=flat-square" alt="Profile views" />
  <img src="https://img.shields.io/github/followers/sadiqur199?label=Followers&style=flat-square&color=2F81F7" alt="Followers" />
  <img src="https://img.shields.io/badge/Available%20for-Freelance-brightgreen?style=flat-square" alt="Available for freelance" />
</p>

<p>
  <a href="https://devsadiq.com/"><img src="https://img.shields.io/badge/Portfolio-devsadiq.com-2F81F7?style=for-the-badge&logo=googlechrome&logoColor=white" alt="Portfolio" /></a>
  <a href="https://linkedin.com/in/sadiqur-rahman-3255b11a3"><img src="https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white" alt="LinkedIn" /></a>
  <a href="mailto:sadiqurrhaman199@gmail.com"><img src="https://img.shields.io/badge/Email-D14836?style=for-the-badge&logo=gmail&logoColor=white" alt="Email" /></a>
  <a href="https://drive.google.com/file/d/1QypCBg3iDUfmEmLi-L5tYIqrGO6Gqxmd/view?usp=sharing"><img src="https://img.shields.io/badge/Resume-Download-black?style=for-the-badge&logo=readthedocs&logoColor=white" alt="Resume" /></a>
</p>

</div>

---

## 👨‍💻 About Me

I'm a **MERN stack developer from Bangladesh** who turns ideas into production-ready web applications.

- 🏢 Working at **Sustainable and Renewable Energy Development Authority (SREDA)**
- 📱 Currently leveling up in **React Native** to build smooth cross-platform mobile apps
- 🌐 All my projects: **[devsadiq.com](https://devsadiq.com/)**
- 💬 Ask me about: **MongoDB · Express · React · Node.js · Next.js**
- 📫 Let's talk: **sadiqurrhaman199@gmail.com**

## 💼 What I Can Build For You

| Service | Details |
|---|---|
| 🌐 **Full-Stack Web Apps** | MERN stack apps: dashboards, e-commerce, SaaS, admin panels |
| 🎨 **Responsive Frontends** | Pixel-perfect React / Next.js UIs with Tailwind, Bootstrap, SASS |
| ⚙️ **REST APIs & Databases** | Secure Node/Express APIs, MongoDB & Firebase integration |
| 📱 **Mobile Apps** *(learning)* | React Native cross-platform apps |

> 📩 **Have a project in mind?** [Email me](mailto:sadiqurrhaman199@gmail.com) or message me on [LinkedIn](https://linkedin.com/in/sadiqur-rahman-3255b11a3).

---

## 🛠️ Tech Stack

<div align="center">
  <img src="https://skillicons.dev/icons?i=html,css,js,bootstrap,sass,tailwind,react,nextjs,nodejs,express,mongodb,firebase,git,linux,ai&perline=8" alt="Tech stack" />
</div>

---

## 🏆 Commit Leaderboard (auto-updated daily)

Ranking of my public repositories by **number of my commits**.

<!--LEADERBOARD:START-->
*Leaderboard will appear here after the first workflow run.*
<!--LEADERBOARD:END-->

---

## 📊 GitHub Stats

<div align="center">
  <img height="180" src="https://github-readme-stats.vercel.app/api?username=sadiqur199&show_icons=true&hide_border=true&include_all_commits=true&count_private=true&theme=tokyonight" alt="GitHub stats" />
  <img height="180" src="https://github-readme-stats.vercel.app/api/top-langs/?username=sadiqur199&layout=compact&hide_border=true&langs_count=6&theme=tokyonight" alt="Top languages" />
</div>

<div align="center">
  <img src="https://streak-stats.demolab.com?user=sadiqur199&theme=tokyonight&hide_border=true" alt="Streak stats" />
</div>

### 📈 Contribution Activity

<img src="https://github-readme-activity-graph.vercel.app/graph?username=sadiqur199&theme=tokyo-night&hide_border=true&area=true" width="100%" alt="Contribution graph" />

### 🥇 Trophies

<div align="center">
  <img src="https://github-profile-trophy.vercel.app/?username=sadiqur199&theme=tokyonight&no-frame=true&no-bg=true&row=1&column=7&margin-w=10" alt="Trophies" />
</div>

---

## 📌 Featured Projects

<!-- REPO_NAME_1, REPO_NAME_2 ... jeikhane tomar best project er repo name boshao -->
<div align="center">
  <a href="https://github.com/sadiqur199/REPO_NAME_1"><img src="https://github-readme-stats.vercel.app/api/pin/?username=sadiqur199&repo=REPO_NAME_1&theme=tokyonight&hide_border=true" alt="Project 1" /></a>
  <a href="https://github.com/sadiqur199/REPO_NAME_2"><img src="https://github-readme-stats.vercel.app/api/pin/?username=sadiqur199&repo=REPO_NAME_2&theme=tokyonight&hide_border=true" alt="Project 2" /></a>
</div>
<div align="center">
  <a href="https://github.com/sadiqur199/REPO_NAME_3"><img src="https://github-readme-stats.vercel.app/api/pin/?username=sadiqur199&repo=REPO_NAME_3&theme=tokyonight&hide_border=true" alt="Project 3" /></a>
  <a href="https://github.com/sadiqur199/REPO_NAME_4"><img src="https://github-readme-stats.vercel.app/api/pin/?username=sadiqur199&repo=REPO_NAME_4&theme=tokyonight&hide_border=true" alt="Project 4" /></a>
</div>

---

## 🐍 Contribution Snake

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/sadiqur199/sadiqur199/output/github-snake-dark.svg" />
  <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/sadiqur199/sadiqur199/output/github-snake.svg" />
  <img alt="Contribution snake" src="https://raw.githubusercontent.com/sadiqur199/sadiqur199/output/github-snake.svg" />
</picture>

<img src="https://capsule-render.vercel.app/api?type=waving&color=gradient&customColorList=12,14,18&height=100&section=footer" width="100%" alt="Footer" />
